---
name: earnings-analysis
description: >-
  Institutional-quality earnings analysis for public equities. Parses 10-Qs,
  earnings releases, and call transcripts into a 4-layer framework (Parse →
  Compare → Diagnose → Decide), runs a mechanical scoring engine that produces
  a composite verdict across beat quality, operational health, and management
  signals, and outputs a one-page earnings sheet, full memo (Word doc), risk
  map, or trade note. Use when asked to analyse earnings, review quarterly
  results, parse a 10-Q, summarise an earnings call, assess earnings quality,
  evaluate beat/miss dynamics, diagnose guidance changes, or produce a
  post-print memo. Triggers include "what did [company] report", "how were
  earnings", "earnings surprise", "quarter review", "results analysis",
  "post-print analysis". Do NOT use for DCF models, long-term thesis work,
  technical analysis, or metals analysis — use the dedicated skills for those.
metadata:
  author: Ed
  version: 1.4.1
  tags:
    - earnings-analysis
    - equity-research
    - quarterly-results
    - financial-statements
    - earnings-call
    - 10-Q
    - investment-research
---

# Earnings Analysis: Institutional-Quality Quarterly Review Framework

## Overview

This skill transforms raw earnings materials (filings, releases, transcripts) into structured investment-grade analysis. It moves beyond simple beat/miss reporting to diagnose *why* results deviated, *what matters* for the forward thesis, and *what action* follows — the way a senior buyside analyst processes a quarter.

**Philosophy**: The market doesn't pay for knowing what happened. It pays for knowing what changed, whether it's repeatable, and what's mispriced. Every earnings analysis must answer: "So what? What do I do now?"

**Two-part architecture.** The skill is a four-layer analytical framework (Parse → Compare → Diagnose → Decide) anchored by a Python scoring engine at `scripts/score_earnings.py` that produces a mechanical composite verdict, flag inventory, and expectations regime classification. The scorer runs at the end of Step 2 and anchors the judgment work in Steps 3 and 4 — it is an input to the diagnosis, not a replacement for it.

## Input Types & Parsing Priority

The skill handles these inputs, in priority order:

| Input Type | What to Extract | How to Access |
|------------|----------------|---------------|
| **User-uploaded files** | Full filing/transcript content | Read from `/mnt/user-data/uploads/` using `pdf-reading` or `file-reading` skills |
| **Earnings release / 8-K** | Headline KPIs, segment data, guidance, non-GAAP reconciliation | Parse uploaded file or search web |
| **10-Q / 10-K filing** | Revenue detail, margin breakdown, balance sheet, cash flow, MD&A | Parse uploaded file or search web |
| **Earnings call transcript** | Management tone, forward commentary, Q&A signals, guidance language | Parse uploaded file or search web |
| **Consensus estimates** | Revenue, EPS, margin expectations, whisper numbers | Web search (Yahoo Finance, Visible Alpha, Seeking Alpha) |
| **Historical quarter data** | Sequential and YoY comparison base | Web search or user-provided |

If files are provided, always start there. If no files, use `web_search` to find the latest earnings materials. Aim for 5–8 searches to gather comprehensive data including consensus expectations and stock reaction context.

---

## Workflow

### Step 0: Input Triage

Before analysis begins, determine what materials are available:

1. Check `/mnt/user-data/uploads/` for uploaded files
2. If files exist, read them using the appropriate method (`/mnt/skills/public/pdf-reading/SKILL.md` for PDFs, `/mnt/skills/public/file-reading/SKILL.md` for other formats)
3. If no files, search for: `[Company] Q[X] [Year] earnings results`, `[Company] earnings call transcript Q[X] [Year]`, `[Company] consensus estimates`, `[Company] stock reaction earnings`
4. Identify the fiscal quarter and reporting date
5. Note what's available vs missing — missing inputs aren't fatal but affect analysis depth

**Validation gate — do not proceed until confirmed:**
- [ ] Company identified with ticker, sector, market cap
- [ ] Reporting quarter identified (fiscal quarter, calendar date)
- [ ] At least ONE primary source obtained (earnings release, filing, or transcript)
- [ ] Prior quarter and prior year baseline data located (or flagged as unavailable)

---

### Step 1: PARSE — Extract Structured Data

Extract data points systematically. Use `references/parsing-checklist.md` for sector-specific KPIs.

#### 1A. Financial KPIs

| Category | Metrics to Extract |
|----------|-------------------|
| **Revenue** | Total revenue, organic growth %, segment breakdown, geographic mix, recurring vs one-time, ASP vs volume decomposition |
| **Margins** | Gross margin, operating margin, EBITDA margin, net margin; GAAP vs non-GAAP reconciliation; SBC as % of revenue |
| **Earnings** | GAAP EPS, adjusted EPS, non-GAAP reconciliation items, share count, buyback contribution to EPS |
| **Cash Flow** | Operating cash flow, free cash flow, capex (growth vs maintenance), working capital, DSO/DIO/DPO trends |
| **Balance Sheet** | Cash, total debt, net debt, debt maturity profile, inventory, goodwill/intangibles, deferred revenue |

#### 1B. Forward Indicators

| Category | What to Extract |
|----------|----------------|
| **Guidance** | Revenue range, EPS range, margin guidance, capex plans, new metrics guided; compare to prior guidance (raised/maintained/lowered); note magnitude (modest/meaningful/massive) |
| **Backlog / Pipeline** | Order book, RPO, bookings, book-to-bill ratio |
| **Leading KPIs** | DAU/MAU, ARR/NRR, same-store sales, subscriber count, pipeline conversion — whatever is sector-relevant |

#### 1C. Management Language Signals

Parse the earnings call transcript (or MD&A section) for:

| Signal Type | What to Flag |
|-------------|-------------|
| **Confidence markers** | "Confident", "strong visibility", "accelerating", "ahead of plan", "raising" |
| **Hedging markers** | "Cautiously optimistic", "uncertain environment", "monitoring closely", "prudent" |
| **Deflection markers** | Pivoting away from questions, "we don't guide to that", avoiding previously guided specifics |
| **New language** | Terms appearing for the first time — often signals strategic pivots or emerging risks |
| **Tone shift** | Compared to prior quarter: is management more/less bullish on specific segments? |
| **Q&A tells** | Which topics drew most follow-ups? What did management dodge? What got a surprisingly detailed answer? |

#### 1D. Stock Context (for Scorer)

Collect data needed to classify expectations elevation:

- Trailing 12-month stock return (%)
- Percentage recovery from 52-week low (%)
- Current drawdown from all-time high (%)
- Stock reaction to the print (positive / flat / negative)

These inputs feed the expectations elevation classifier in the scoring engine, which determines how the market's reaction should be interpreted relative to the underlying fundamentals.

**Validation gate — do not proceed until confirmed:**
- [ ] Revenue, EPS, margin extracted (GAAP and non-GAAP where applicable)
- [ ] At least one forward indicator captured (guidance, backlog, or leading KPI)
- [ ] Management language scan completed (or flagged as "no transcript available")
- [ ] Stock context collected for scorer inputs
- [ ] Data gaps explicitly noted

---

### Step 2: COMPARE — Multi-Horizon Benchmarking

Every extracted metric needs context. Raw numbers are meaningless without a reference frame.

#### 2A. Sequential (QoQ) Comparison

- Revenue growth trajectory: accelerating, stable, or decelerating?
- Margin expansion or compression vs prior quarter?
- Cash conversion trend?
- Guidance change: raised, maintained, or lowered vs prior quarter's guidance?

#### 2B. Year-over-Year (YoY) Comparison

- Organic revenue growth (exclude acquisitions, FX, one-offs)
- Margin change with driver attribution (mix shift, pricing, cost, scale)
- EPS growth decomposed into operational vs financial engineering (buybacks, tax rate, below-the-line items)

#### 2C. Versus Consensus

The market prices off expectations, not absolutes. This is the most important comparison.

| Metric | Reported | Consensus | Delta | Interpretation |
|--------|----------|-----------|-------|----------------|
| Revenue | | | | Beat/miss magnitude; quality of beat (one-time vs sustainable) |
| EPS | | | | Decompose: operational or below-the-line? |
| Guidance midpoint | | | | Forward expectations raised/lowered? |
| Key segment | | | | Where did the surprise come from? |

**Beat quality matters more than beat size.** A 2% revenue beat from pull-forward demand is worse than a 0.5% beat from new customer wins. Always diagnose the source. Also note whisper numbers where available — a beat that meets consensus but misses whisper will trade negatively.

#### 2D. Versus Peers

- Did the company outperform or underperform sector trends?
- Are margin differences structural or timing-driven?
- Is the company gaining or losing share?

#### 2E. Versus Valuation History

- Current forward P/E vs 5-year average
- EV/Revenue or EV/EBITDA relative to growth rate
- How has the market historically repriced this stock after similar quarters?

---

### Step 2.5: RUN THE SCORING ENGINE

Once Compare is substantially complete, invoke the scorer to produce a mechanical composite verdict that anchors Steps 3 and 4. The scorer is at `scripts/score_earnings.py`. See the **Scoring Engine Reference** section below for the full input schema, verdict tiers, flag library, and sample invocation.

The scorer output gives you:
- Composite score (integer, typically -15 to +18)
- Base verdict tier (STRONG / SOLID / MIXED / WEAK / PROBLEMATIC)
- Verdict suffix modifiers where applicable (_AT_PEAK, _EXPECTATIONS_OVERRUN, _WITH_CRITICAL_FLAGS)
- Expectations regime (constructive / overrun / whisper_overrun / depressed / balanced / deteriorating)
- Expectations elevation (low / medium / high / extreme)
- Complete flag inventory with narrative text
- Output recommendation (which deliverables to produce)

Treat the scorer verdict as a hypothesis to be validated or overridden by the judgment work in Step 3. If you disagree with the scorer, explain why — the scorer catches mechanical patterns but can miss narrative, competitive, or regulatory context that matters for the investment thesis.

**Validation gate — do not proceed until confirmed:**
- [ ] QoQ and YoY comparison completed for revenue, margins, EPS
- [ ] Consensus comparison completed (at minimum: revenue and EPS vs estimates)
- [ ] Beat/miss quality diagnosed (operational vs one-time/financial engineering)
- [ ] Forward guidance compared to consensus expectations
- [ ] Scoring engine invoked and output captured

---

### Step 3: DIAGNOSE — Explain What Changed and Why

This is the analytical core. Move from *what happened* to *why it happened* and *whether it persists*. Every scorer flag that fired must be addressed in the diagnosis.

#### 3A. Growth Diagnosis

- What drove the revenue delta? (volume, pricing, mix, FX, acquisitions, one-offs)
- Is the growth rate accelerating, stable, or decelerating? What's the second derivative?
- Are leading indicators (bookings, pipeline, DAU, ARR) confirming or diverging from reported growth?
- Is growth quality improving? (recurring > one-time, organic > acquired, high-margin > low-margin)

#### 3B. Margin Diagnosis

- Was margin change driven by gross margin or opex leverage?
- Gross margin drivers: input costs, pricing power, mix shift, scale
- Opex drivers: hiring pace, R&D investment, S&M efficiency, G&A leverage
- For high-GM businesses (pharma, software, luxury), operating margin trajectory matters more than gross margin — OPM compression without GM compression signals operating deleverage or opex ramp
- Is SBC growing faster than revenue?
- Is management guiding for margin expansion or reinvestment?

#### 3C. Cash Quality Diagnosis

- OCF/NI conversion — is earnings quality high? (OCF is more reliable than FCF for quality signal because it excludes capex noise)
- FCF/NI conversion — and is low FCF a quality concern or a growth capex mode signal?
- Working capital — is DSO rising (revenue recognition concern)? Is inventory building (demand risk)?
- Capex intensity — growth vs maintenance split; what's the return profile?

#### 3D. Balance Sheet Risk Diagnosis

- Net debt trajectory — improving or deteriorating?
- Debt maturity wall — any near-term refinancing risk?
- Goodwill/intangibles as % of total assets — impairment risk?
- Off-balance-sheet exposures (operating leases, unconsolidated entities, guarantees)

#### 3E. Narrative Shift Diagnosis

This is often the most alpha-generative layer.

- Has management's strategic narrative changed from prior quarters?
- Are there new buzzwords, new segment disclosures, or new metrics being emphasised?
- Has the investment thesis evolved? (growth story becoming a margin story, or vice versa)
- What did management stop talking about? (often more telling than what they started saying)
- Did the CEO/CFO tone shift between prepared remarks and Q&A?

**Validation gate — do not proceed until confirmed:**
- [ ] Growth, margin, and cash flow drivers each diagnosed with specific attribution
- [ ] Repeatability assessed for each major driver (one-time vs structural)
- [ ] Narrative shift (or continuity) identified with evidence
- [ ] Every scorer flag that fired has been addressed in the diagnosis
- [ ] At least one non-obvious insight surfaced beyond the headline beat/miss

---

### Step 4: DECIDE — Translate to Investment Action

The final layer converts diagnosis into actionable output.

#### 4A. The Verdict: What Changed

Summarise in 2–3 sentences:
- What is the single most important thing that changed this quarter?
- Does this change strengthen, weaken, or leave unchanged the prior investment thesis?
- Is this a thesis-confirming, thesis-evolving, or thesis-breaking quarter?

The scorer verdict is the mechanical anchor. Your written verdict should agree with it or explicitly explain why you're overriding it.

#### 4B. Scenario Framework

| Scenario | Description | Probability | Implied Valuation |
|----------|-------------|-------------|-------------------|
| **Bull** | What goes right from here — extrapolate positive trends | | |
| **Base** | Current trajectory continues — management delivers on guidance | | |
| **Bear** | What could go wrong — risks materialise, growth disappoints | | |

For each scenario, describe the revenue/margin trajectory, the key assumption, and rough valuation implications.

#### 4C. Repricing Path

- What would cause the street to revise estimates up or down?
- Is there a catalyst calendar ahead? (next quarter, product launch, regulatory decision, M&A)
- Is the stock likely to re-rate on this quarter, or is it a "show me" story?

#### 4D. Trade/Research Implications

| If Position | Action | Rationale |
|-------------|--------|-----------|
| **Long** | Add / Hold / Trim / Exit | Why? What changed for the position? |
| **Short** | Cover / Hold / Add | Why? Is the bear case weakening or strengthening? |
| **No position** | Initiate / Watchlist / Pass | Why? What would trigger a position? |

#### 4E. Risk Triggers & Invalidation

Identify 3–5 specific, measurable conditions that would invalidate the current view:
- e.g., "If organic growth falls below 5% for two consecutive quarters"
- e.g., "If gross margin drops below 60% excluding one-time charges"
- e.g., "If management lowers FY guidance by more than 5% at midpoint"

These should be concrete and monitorable, not vague risk factors.

---

## Scoring Engine Reference

The scoring engine at `scripts/score_earnings.py` converts parsed earnings data into a composite verdict across three analytical layers. Current version is v1.4.1, validated against nine distinct earnings cases spanning every major verdict tier from STRONG_QUARTER through PROBLEMATIC_QUARTER_WITH_CRITICAL_FLAGS and every defined expectations regime.

### Invocation

The scorer takes command-line arguments that mirror the data points extracted in Steps 1 and 2. Output is JSON. A representative invocation:

```bash
python scripts/score_earnings.py \
  --ticker "XYZ" --quarter "Q4 2025" \
  --revenue-beat-pct 1.5 --eps-beat-pct 3.0 \
  --guidance-change raised --guidance-raise-magnitude modest \
  --gross-margin-change-bps 50 --gross-margin-change-yoy-bps 100 \
  --gross-margin-vs-5y-percentile 60 \
  --core-segment-gm-gap-pp 0 --beat-driver volume \
  --operating-margin-change-qoq-bps 20 --operating-margin-change-yoy-bps 80 \
  --ocf-conversion 1.05 --fcf-conversion 0.85 \
  --dso-change-days 2 --inventory-growth-pct 10 --revenue-growth-pct 12 \
  --gaap-nongaap-op-margin-gap-pp 3 --capex-to-revenue-ratio 8 \
  --management-tone confident --stock-reaction positive \
  --stock-1y-return-pct 25 --stock-return-from-low-pct 60 --stock-drawdown-from-high-pct 10 \
  --red-flags '[]'
```

All inputs have sensible defaults so partial invocation is possible. Missing inputs should be explicitly noted in Step 3 so the reader understands which dimensions of the score are based on assumed values rather than disclosed data.

### Input Schema

**Beat quality inputs.** `revenue-beat-pct` and `eps-beat-pct` are signed percentage surprises versus consensus. `guidance-change` takes one of: `raised`, `raised_narrowed`, `maintained`, `narrowed_lowered`, `lowered`, `withdrawn`, `initiated`, `not_provided`. `guidance-raise-magnitude` (for both raises and cuts) takes `modest`, `meaningful`, or `massive`. `gross-margin-change-bps` is sequential, `gross-margin-change-yoy-bps` is annual. `gross-margin-vs-5y-percentile` is 0–100. `core-segment-gm-gap-pp` is the core segment's GM minus consolidated GM in percentage points. `beat-driver` takes `volume`, `mix`, `pricing`, `one_time_favourable`, `one_time_unfavourable`, `fx`, or `unknown` (legacy `one_time` maps to favourable). `operating-margin-change-qoq-bps` and `operating-margin-change-yoy-bps` capture operating-margin dynamics.

**Operational health inputs.** `ocf-conversion` is OCF/net income (primary cash quality metric). `fcf-conversion` is FCF/net income (secondary, interpreted alongside capex intensity). `dso-change-days` is sequential DSO change. `inventory-growth-pct` is YoY inventory growth, compared to `revenue-growth-pct`. `gaap-nongaap-op-margin-gap-pp` captures SBC/adjustment magnitude. `capex-to-revenue-ratio` (new in v1.4.1) enables growth-capex-mode detection for high-intensity investment cycles.

**Management signals inputs.** `management-tone` takes `bullish`, `confident`, `neutral`, `cautious`, `defensive`, or `evasive`. `stock-reaction` takes `positive`, `flat`, or `negative`. `stock-1y-return-pct`, `stock-return-from-low-pct`, and `stock-drawdown-from-high-pct` feed the expectations elevation classifier. `red-flags` is a JSON array of flag keys drawn from the library documented below — use the exact snake_case keys listed in the Flag Library.

### Layer 1: Beat Quality

Evaluates beat magnitude, guidance direction and magnitude, gross margin and operating margin dynamics, beat-driver persistence, and contradictions such as beat-and-cut. Rewards clean volume-driven beats with raised guidance and positive margin trends. Penalises pricing-driven beats, one-time favourable flatters, guidance cuts, margin compression (sequential or annual), and operating deleverage. Typical range: -8 to +10.

### Layer 2: Operational Health

Evaluates cash conversion, working capital discipline, and the GAAP/non-GAAP gap. OCF/NI is the primary cash quality metric because it excludes capex variability. FCF/NI enters through a growth-capex-mode check that distinguishes genuine FCF weakness from heavy investment cycles. As of v1.4.1, growth capex mode fires when FCF conversion is low AND OCF is healthy AND (revenue growth >15% OR capex-to-revenue ratio >25%). Typical range: -6 to +5.

### Layer 3: Management Signals

Evaluates management tone, governance and reporting red flags, the market reaction, and the interaction between reaction and expectations elevation. This layer also hosts the expectations regime classifier. Typical range: -8 to +3.

### Expectations Elevation Classifier

A 0–9 composite that measures how much optimism is priced into the stock heading into the print. Three independent sub-scores each 0–3:

- **Recent momentum** — trailing 12-month return (0 for <30%, 3 for >150%)
- **Rally maturity** — recovery from 52-week low (0 for <100%, 3 for >400%)
- **Cushion erosion** — drawdown from all-time high (0 for >30%, 3 for <5%)

The total maps to four tiers: **low** (0–2), **medium** (3–4), **high** (5–6), **extreme** (7–9). Elevation matters because it determines how the market's reaction should be interpreted. A beat that would normally be received positively can produce a negative reaction at extreme elevation because the whisper has moved ahead of consensus. Conversely, a miss at low elevation may produce a muted or positive reaction because expectations are already reset.

### Expectations Regime Classifier

Produces a single label summarising the relationship between the current print, forward guidance, market reaction, and expectations elevation. Seven regimes exist at v1.4.1:

| Regime | Pattern | Interpretation |
|--------|---------|----------------|
| **constructive** | Beat + raise + positive reaction | Clean thesis confirmation; asymmetric upside flag fires at low elevation |
| **overrun** | Beat-and-raise with negative reaction, or beat-without-raise at elevated stock | Whisper was ahead of guidance; forward risk/reward has asymmetrically worsened |
| **whisper_overrun** (v1.4.1) | Beat + maintained guidance + negative reaction at low/medium elevation | Narrow-band whisper disappointed on a specific key metric; reaction is real but not thesis-breaking |
| **depressed** | Headline miss with positive reaction | Expectations reset below reported results; leveraged upside regime |
| **balanced** | Beat + flat reaction | Market has neither revised up nor down |
| **deteriorating** | Negative reaction + guidance cut (regardless of current-quarter beat/miss) | Most severe regime; expectations may still be ahead of reality |
| **unknown** | No branch matches | Should not occur in practice at v1.4.1 |

**Branch precedence.** The deteriorating check runs first for any negative reaction combined with a guidance cut, ensuring that beat-and-cut cases (like Novo Nordisk Q4 2025) are classified as deteriorating rather than whisper_overrun.

### Verdict Tiers and Routing

The composite score is the sum of the three layer scores. Five base tiers:

| Tier | Score Range | Meaning |
|------|-------------|---------|
| **STRONG_QUARTER** | ≥ 9 | Clean beat with quality confirming; thesis-confirming |
| **SOLID_QUARTER** | 4 to 8 | Decent quarter, no major red flags; thesis maintained |
| **MIXED_QUARTER** | 0 to 3 | Mixed signals; further diagnosis required |
| **WEAK_QUARTER** | -4 to -1 | Below expectations or quality concerns present |
| **PROBLEMATIC_QUARTER** | ≤ -5 | Material miss and/or serious red flags; thesis may be impaired |

Three suffix modifiers can attach:

- **_AT_PEAK** — attaches to STRONG or SOLID when the peak cycle risk flag fired. Results are strong but mean reversion risk is elevated.
- **_EXPECTATIONS_OVERRUN** — attaches to STRONG or SOLID when the overrun regime is detected. Fundamentals are strong but market has priced in execution; the question shifts from direction to position sizing.
- **_WITH_CRITICAL_FLAGS** — attaches to any base tier when critical flags fire. STRONG, SOLID, and MIXED cases are downgraded to MIXED_QUARTER_WITH_CRITICAL_FLAGS. WEAK and PROBLEMATIC retain their base label with the suffix appended.

### Critical Flag Override

Eight flag keys are classified as critical and trigger the WITH_CRITICAL_FLAGS suffix regardless of the base composite score: **CFO_DEPARTURE**, **AUDITOR_CHANGE**, **RESTATEMENT**, **BEAT_AND_CUT**, **DESTRUCTIVE_BUYBACK**, **LOW_OCF**, **GAAP_NONGAAP_GAP_EXTREME**, and **REGULATORY_ENFORCEMENT**.

Critical flags apply as a downgrade modifier while the underlying composite score is preserved in the verdict detail text, so the reader sees both the mechanical score and the specific concern that caused the downgrade. When the base verdict is already PROBLEMATIC_QUARTER, the verdict detail reads "confirmed by" rather than "downgraded due to" because the critical flag is reinforcing rather than overriding the base classification.

### Verdict-Driven Output Routing

The scorer emits an `output_recommendation` that maps the verdict tier to deliverable types. This routing takes precedence over any default deliverable selection — produce what the scorer recommends unless the user explicitly requests something else.

| Verdict Tier | Output Recommendation |
|-------------|----------------------|
| STRONG_QUARTER | One-page earnings sheet |
| STRONG_QUARTER_AT_PEAK | Full memo + risk map (peak cycle focus) |
| STRONG_QUARTER_EXPECTATIONS_OVERRUN | Full memo (position sizing focus) |
| SOLID_QUARTER | Full memo |
| SOLID_QUARTER_AT_PEAK | Full memo + risk map (peak cycle focus) |
| SOLID_QUARTER_EXPECTATIONS_OVERRUN | Full memo (position sizing focus) |
| MIXED_QUARTER | Full memo |
| MIXED_QUARTER_WITH_CRITICAL_FLAGS | Full memo + risk map (critical flag investigation) |
| WEAK_QUARTER | Full memo + risk map |
| WEAK_QUARTER_WITH_CRITICAL_FLAGS | Full memo + risk map (critical flag investigation) |
| PROBLEMATIC_QUARTER | Full memo + risk map |
| PROBLEMATIC_QUARTER_WITH_CRITICAL_FLAGS | Full memo + risk map (critical flag investigation) |

The trade note is produced on user request in addition to any of the above.

---

## Flag Library Reference

The scoring engine maintains a structured library of flags that fire when specific conditions are detected. Each flag carries a score impact (which can be zero for narrative-only flags), a narrative text, and in some cases a classification as a critical flag. The Score column shows the direct impact on the layer score — flags marked "narrative" have zero score impact but appear in the output to inform the diagnosis.

Critical flags are marked with an asterisk.

### Beat Quality Layer

| Flag Name | Input Condition | Score | Purpose |
|-----------|----------------|-------|---------|
| EXTREME_BEAT | Revenue beat >15% or EPS beat >20% | narrative | Model-breaking magnitude — investigate sustainability vs peak cycle |
| GUIDANCE_MASSIVE_RAISE | Guide raised >15% above consensus | narrative | Expect broad analyst revisions; watch for peak cycle reversal |
| CORE_SEGMENT_PREMIUM | Core segment GM gap >8pp above consolidated | +1 | Headline margin understates core business quality |
| CORE_SEGMENT_HIGHER | Core segment GM gap 3–8pp above consolidated | narrative | Modest positive context for margin reading |
| CORE_SEGMENT_DRAG | Core segment GM gap <-5pp | -1 | Core business worse than headline suggests |
| QOQ_MARGIN_NOISE | QoQ GM decline suppressed by YoY positive or core premium | 0 or -1 | Mix-quarter noise, not structural compression |
| GROSS_MARGIN_COMPRESSION | QoQ GM decline >200bps with YoY trend also weak | -2 | Structural margin erosion |
| MARGIN_PRESSURE | QoQ GM decline 100–200bps not offset by YoY | -1 | Margin pressure without annual offset |
| YOY_MARGIN_DETERIORATION | YoY GM decline 200–400bps | -1 | Annual margin trend turned negative; verify structural vs transitory |
| YOY_MARGIN_DETERIORATION_SEVERE | YoY GM decline >400bps | -2 | Severe structural margin compression |
| OPM_DETERIORATION | YoY OPM decline 250–500bps | -1 | Annual operating leverage turning negative |
| OPM_DETERIORATION_SEVERE | YoY OPM decline >500bps | -2 | Structural operating deleverage; critical for high-GM businesses |
| OPM_GM_DIVERGENCE | OPM compressing QoQ (<-100bps) while GM stable (>-50bps) | -1 | Issue is below the gross margin line |
| PEAK_CYCLE_RISK | GM at 90th+ percentile of 5-year history | narrative | Mean reversion risk; triggers _AT_PEAK suffix |
| ONE_TIME_FAVOURABLE_BEAT | `beat-driver = one_time_favourable` | -3 | Current period flattered by non-recurring positive |
| ONE_TIME_UNFAVOURABLE | `beat-driver = one_time_unfavourable` | +1 | Current period depressed by non-recurring negative |
| PRICING_DRIVEN_BEAT | `beat-driver = pricing` with large surprise | narrative | Pricing beats have shorter half-lives than volume beats |
| BEAT_AND_CUT* | Revenue beat paired with guidance cut | -2 | Classic pull-forward signal; critical flag |
| EPS_QUALITY | EPS beat without revenue beat | narrative | Check tax rate, below-the-line items, buybacks |
| GUIDANCE_WITHDRAWN | `guidance-change = withdrawn` | -4 | Major uncertainty signal |

### Operational Health Layer

| Flag Name | Input Condition | Score | Purpose |
|-----------|----------------|-------|---------|
| LOW_OCF* | OCF/NI below 0.40 | -3 | Serious earnings quality concern; critical flag |
| OCF_QUALITY | OCF/NI 0.40 to 0.60 | -1 | Earnings quality concern |
| GROWTH_CAPEX_MODE | Low FCF + healthy OCF + (rev growth >15% OR capex/rev >25%) | narrative | Capex funding growth/infrastructure; not a quality concern |
| FCF_WEAKNESS | FCF/NI <0.5 without growth or capex offset | -1 | Cash conversion issue without clear explanation |
| DSO_SPIKE | DSO increased >10 days QoQ | -2 | Revenue recognition or collections risk |
| DSO_RISING | DSO increased 5–10 days QoQ | -1 | Monitor collections |
| INVENTORY_BUILD | Inventory growing >15pp faster than revenue | -2 | Demand risk, potential write-down |
| INVENTORY_WATCH | Inventory growing 5–15pp faster than revenue | -1 | Monitor inventory vs demand |
| GAAP_NONGAAP_GAP | Operating margin gap 15–25pp | -1 | Notable SBC/adjustment magnitude |
| GAAP_NONGAAP_GAP_EXTREME* | Operating margin gap >25pp | -2 | Investigate whether excluded items are truly one-time; critical flag |

### Management Signals Layer

Red flag keys in the table below are passed to the scorer via the `--red-flags` argument as a JSON array of snake_case strings. Example: `--red-flags '["cfo_departure","doj_investigation"]'`. Expectations regime flags are emitted automatically based on the stock reaction and guidance change inputs — you do not pass them in explicitly.

**Governance & quality red flags (pass via --red-flags):**

| Input Key | Output Flag | Score | Category |
|-----------|------------|-------|----------|
| `cfo_departure` | CFO_DEPARTURE* | -3 | Governance |
| `auditor_change` | AUDITOR_CHANGE* | -3 | Governance |
| `restatement` | RESTATEMENT* | -4 | Governance |
| `new_non_gaap_adjustments` | NEW_NON_GAAP | -2 | Quality |
| `guidance_metric_dropped` | METRIC_DROPPED | -2 | Quality |
| `guidance_cut_with_beat` | BEAT_AND_CUT | -2 | Quality (also auto-fires from beat/guidance combo) |
| `buyback_with_debt_and_declining_roic` | DESTRUCTIVE_BUYBACK* | -2 | Capital allocation |
| `insider_selling_spike` | INSIDER_SELLING | -1 | Insider behaviour |
| `segment_restructuring` | SEGMENT_CHANGE | -1 | Reporting |
| `deferred_revenue_decline` | DEFERRED_REV_DECLINE | -1 | Forward demand |

**Regulatory overhang red flags (pass via --red-flags):**

| Input Key | Output Flag | Score | Category |
|-----------|------------|-------|----------|
| `doj_investigation` | DOJ_INVESTIGATION | -2 | Regulatory overhang |
| `sec_investigation` | SEC_INVESTIGATION | -2 | Regulatory overhang |
| `antitrust_review` | ANTITRUST_REVIEW | -2 | Regulatory overhang |
| `regulatory_enforcement_action` | REGULATORY_ENFORCEMENT* | -3 | Regulatory overhang |
| `doj_settlement_risk` | DOJ_SETTLEMENT_RISK | -1 | Regulatory overhang |
| `executive_departure_senior` | EXECUTIVE_DEPARTURE | -2 | Leadership transition |

**Expectations regime flags (auto-fired, not passed in):**

| Output Flag | Condition | Score |
|------------|-----------|-------|
| EXPECTATIONS_BAR_RISING | Negative reaction to beat-and-raise | -1 |
| HOT_STOCK_MODEST_BEAT | Negative reaction to beat at elevated stock | -1 |
| WHISPER_OVERRUN | Negative reaction to beat at low/medium elevation without raise | -1 |
| EXPECTATIONS_BAR_LOW | Positive reaction to headline miss | +1 |
| ASYMMETRIC_UPSIDE | Beat-and-raise at low elevation with positive reaction | +1 |
| DETERIORATING_REGIME | Negative reaction paired with guidance cut | narrative |
| ELEVATION_EXTREME | Overrun pattern at extreme elevation (additional penalty) | -1 |

**Custom flags.** Any `red-flags` key not in the standard library will be passed through as `CUSTOM_FLAG: <key>` with no score impact, for cases where you need to note something outside the standard taxonomy.

---

## Output Deliverables

The scoring engine's `output_recommendation` drives which deliverables to produce. Always honour the routing unless the user explicitly requests something different.

### Output 1: One-Page Earnings Sheet

Default output for STRONG_QUARTER cases. A single-page summary as a Word document. Read `/mnt/skills/public/docx/SKILL.md` before building.

Structure:

```
┌─────────────────────────────────────────────────┐
│  [Company] (TICKER) — Q[X] FY[YYYY]            │
│  Sector | Market Cap | Report Date              │
├─────────────────────────────────────────────────┤
│  VERDICT: [Scorer tier] — [1-sentence summary] │
├────────────────────┬────────────────────────────┤
│  KEY METRICS       │  BEAT / MISS SCORECARD    │
│  Revenue: $X.Xbn   │  Rev: Beat/Miss by X%     │
│  Gross Margin: XX% │  EPS: Beat/Miss by $X.XX  │
│  Op Margin: XX%    │  Guide: Raised/Held/Cut   │
│  EPS: $X.XX        │  Quality: Vol/Mix/Price   │
│  FCF: $X.Xbn       │                            │
├────────────────────┴────────────────────────────┤
│  WHAT CHANGED (3 bullets max)                   │
├─────────────────────────────────────────────────┤
│  GROWTH DRIVERS    │  MARGIN DRIVERS           │
├─────────────────────────────────────────────────┤
│  MANAGEMENT TONE: [tone] — [evidence]          │
├─────────────────────────────────────────────────┤
│  SCENARIO TABLE (Bull / Base / Bear)            │
├─────────────────────────────────────────────────┤
│  ACTION: [position-specific]                    │
│  RISK TRIGGERS: [2-3 invalidation conditions]   │
└─────────────────────────────────────────────────┘
```

### Output 2: Full Earnings Memo

Default output for SOLID, MIXED, WEAK, and PROBLEMATIC cases, and for any strong case with an AT_PEAK or EXPECTATIONS_OVERRUN suffix. A 4–6 page Word document. Read `/mnt/skills/public/docx/SKILL.md` before building.

- **Page 1**: Cover + Verdict — scorer output, composite score, base tier, regime, elevation, and a 2-sentence summary
- **Page 2**: Parsed Financials — segment breakdown, GAAP/non-GAAP reconciliation, KPI table
- **Page 3**: Comparison Matrix — QoQ, YoY, vs consensus, vs peers (table format)
- **Page 4**: Diagnosis — growth, margin, cash, balance sheet, narrative shift; must address every flag that fired in the scorer
- **Page 5**: Decision Framework — scenarios, repricing path, action, risk triggers
- **Page 6**: Appendix — paraphrased management quotes, Q&A summary, data sources

**Formatting.** Navy (#1B2A4A) headers, accent blue (#2E75B6) highlights, light grey (#F5F5F5) alternating rows. Body text 10pt Arial. Tables with thin borders. Concise — every sentence must earn its place.

### Output 3: Risk Map

Produced whenever the scorer's output_recommendation includes "+ RISK_MAP". A structured risk assessment as a markdown table or React component:

| Risk Category | Specific Risk | Probability | Impact | Trend | Monitoring Metric |
|--------------|--------------|-------------|--------|-------|-------------------|
| Growth | Deceleration | Med/High/Low | High/Med/Low | ↑↓→ | Organic growth rate |
| Margin | Input cost pressure | ... | ... | ... | Gross margin % |
| Regulatory | DOJ investigation | ... | ... | ... | Court filings, settlement disclosures |

For critical-flag cases, include a dedicated row for each critical flag with a specific monitoring metric and an explicit invalidation condition.

### Output 4: Trade Note

Produced on user request in addition to the default deliverables. 3–5 paragraphs for a portfolio manager or trading desk:

- Line 1: Ticker, quarter, beat/miss summary
- Para 1: What happened (2–3 sentences, numbers only)
- Para 2: What matters (the diagnosis)
- Para 3: What to do (the action)
- Final line: Key risk trigger

---

## Sector-Specific Parsing Extensions

Different sectors require different KPIs. Read `references/parsing-checklist.md` for the full sector-specific extraction guide. Key examples:

| Sector | Additional KPIs |
|--------|----------------|
| **SaaS / Cloud** | ARR, NRR, RPO, customer count, DBNR, Rule of 40, CAC payback |
| **Semiconductors** | Revenue by end market, ASP trends, utilisation, inventory channel fill, design wins, HBM/AI mix |
| **Biotech / Pharma** | Pipeline updates, FDA milestones, Rx volumes, launch curves, patent cliffs, R&D productivity |
| **Banks / Financials** | NIM, loan growth, deposit costs, credit quality (NCO, NPL, reserves), CET1, fee income mix |
| **Consumer / Retail** | Same-store sales, traffic vs ticket, inventory turns, e-commerce mix, promotional activity |
| **Industrials** | Organic orders, book-to-bill, backlog, price vs volume, segment margin bridge |
| **REITs** | FFO/AFFO, occupancy, lease spreads, same-property NOI, development pipeline |
| **Energy** | Production volumes, realised prices, unit costs, reserves replacement, breakeven price |

---

## Process Discipline

1. **Layer sequence matters.** Don't skip to judgment before parsing, comparing, and running the scorer. The framework is designed to prevent premature conclusions.
2. **Every scorer flag must be addressed in the diagnosis.** A flag that fires without comment is a missed opportunity; a flag that fires and is explained away is an explicit analytical choice.
3. **Be opinionated but transparent.** The best buyside research takes a view. Don't hedge with "on the one hand / on the other hand" — make a call and state what would change your mind. If you override the scorer verdict, explain why.
4. **Time-stamp everything.** Earnings analysis is perishable. Always note the reporting date and when the analysis was produced.

---

## Quick Reference: The 4-Layer Summary

```
Layer 1: PARSE      → What happened? (Revenue, margins, EPS, cash, balance sheet, stock context)
Layer 2: COMPARE    → How does it stack up? (QoQ, YoY, vs consensus, vs peers, vs valuation)
          → Run scorer at end of Compare for mechanical verdict
Layer 3: DIAGNOSE   → Why did it happen? Is it repeatable? What shifted? Address every scorer flag.
Layer 4: DECIDE     → So what? What's the action? What would change my mind?
```

The one-page sheet is the minimum viable output for STRONG cases. The full memo is the default for everything else. Always end with a clear view and specific invalidation conditions.
